var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/handlers/appointmentConfirm.ts
var appointmentConfirm_exports = {};
__export(appointmentConfirm_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(appointmentConfirm_exports);
var AWS = __toESM(require("aws-sdk"));
var ddb = new AWS.DynamoDB.DocumentClient({ region: "us-east-2" });
var eventBridge = new AWS.EventBridge({ region: "us-east-2" });
var handler = async (event) => {
  console.log("Evento recibido en appointmentConfirm:", JSON.stringify(event, null, 2));
  for (const record of event.Records) {
    try {
      await processConfirmation(record);
    } catch (error) {
      console.error("Error procesando registro SQS:", {
        messageId: record.messageId,
        body: record.body,
        error
      });
    }
  }
};
var processConfirmation = async (record) => {
  const appointmentKeys = JSON.parse(record.body);
  console.log("Procesando confirmaci\xF3n para appointmentId:", appointmentKeys.appointmentId);
  const params = {
    TableName: process.env.APPOINTMENTS_TABLE,
    Key: { appointmentId: appointmentKeys.appointmentId },
    UpdateExpression: "SET #status = :status",
    ExpressionAttributeNames: { "#status": "status" },
    ExpressionAttributeValues: { ":status": "completed" }
  };
  await ddb.update(params).promise();
  console.log(`\u2705 Estado actualizado a 'completed' para ${appointmentKeys.appointmentId}`);
  const eventParams = {
    Entries: [
      {
        Source: "rimac.appointments",
        DetailType: "Appointment Confirmed",
        Detail: JSON.stringify({ appointmentId: appointmentKeys.appointmentId }),
        EventBusName: "default"
      }
    ]
  };
  await eventBridge.putEvents(eventParams).promise();
  console.log(`\u2705 Evento enviado a EventBridge para ${appointmentKeys.appointmentId}`);
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
//# sourceMappingURL=appointmentConfirm.js.map
